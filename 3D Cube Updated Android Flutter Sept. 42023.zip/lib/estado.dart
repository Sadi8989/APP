import 'package:equatable/equatable.dart';

class Estado extends Equatable {
  const Estado();
  

  @override
  List<Object> get props => [];
}

class InicioE extends Estado {}

class Lado1E extends Estado {}
class Lado2E extends Estado {}
class Lado3E extends Estado {}
class Lado4E extends Estado {}



class ErrorE extends Estado {}