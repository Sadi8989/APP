import 'package:SocialNetworksAllinOne/cubobloc.dart';
import 'package:SocialNetworksAllinOne/estado.dart';
import 'package:flutter/material.dart';
import 'package:SocialNetworksAllinOne/myaccountspage.dart';
import 'package:SocialNetworksAllinOne/galdy.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';


void main() {
  WidgetsFlutterBinding.ensureInitialized();
  MobileAds.instance.initialize();
  runApp(
    MultiBlocProvider(
          providers: [
            BlocProvider<CuboBloc>(
              create: (context) =>
                  CuboBloc(InicioE()),
            ),],
          child: MyApp()
      )
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: 'SF Pro Display', canvasColor: Colors.black),
      title: Galdy().nombre,
      home: MyAccountsPage(),
    );
  }
}

