import 'dart:io';

class Galdy {
  // String appID = "ca-app-pub-4475365463263410~6680889385";
  // String interID = "ca-app-pub-2602311954042540/2355738788";
  // String bannerID = "ca-app-pub-4475365463263410/8543160616";

  String appID = (Platform.isAndroid)
      // ? "ca-app-pub-4475365463263410~6680889385"
      ? "ca-app-pub-4475365463263410~6680889385" //Android Test AppId
      : "ca-app-pub-5512694281985389/8906755529";
  String bannerID = (Platform.isAndroid)
      // ? "ca-app-pub-5512694281985389/2370849915"
      ? "ca-app-pub-3940256099942544/6300978111"   //Android Test bannerID
      : "ca-app-pub-5512694281985389/8906755529";
  String interID = (Platform.isAndroid)
      // ? "ca-app-pub-5512694281985389/8544348358"
      ? "ca-app-pub-3940256099942544/1033173712" //Android Test InterId
      : "ca-app-pub-5512694281985389/6256734970";

  String nombre = "Social Networks All in One 3D Media Cube";
  String color1 = "bdc3c7";
  String color2 = "2c3e50";
}
