import 'package:equatable/equatable.dart';

class Evento extends Equatable {
  const Evento();
  

  @override
  List<Object> get props => [];
}

class Inicio extends Evento {}

class Lado1 extends Evento {}
class Lado2 extends Evento {}
class Lado3 extends Evento {}
class Lado4 extends Evento {}



