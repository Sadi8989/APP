import 'dart:math' as math;
import 'dart:ui';

import 'package:SocialNetworksAllinOne/cubobloc.dart';
import 'package:SocialNetworksAllinOne/estado.dart';
import 'package:SocialNetworksAllinOne/eventos.dart';
import 'package:SocialNetworksAllinOne/panel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:provider/provider.dart';
import 'package:simple_animations/simple_animations.dart';
import 'package:supercharged/supercharged.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'constants.dart';
import 'galdy.dart';

class Navegador extends StatefulWidget {
  final WebView nav;

  Navegador(this.nav);

  @override
  _NavegadorState createState() => _NavegadorState(this.nav);
}

class _NavegadorState extends State<Navegador>
    with AutomaticKeepAliveClientMixin {
  final WebView nav;

  _NavegadorState(this.nav);

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[nav],
    );
  }

  @override
  bool get wantKeepAlive => true;
}

class MyAccountsPage extends StatefulWidget {
  @override
  _MyAccountsPageState createState() => _MyAccountsPageState();
}

class _MyAccountsPageState extends State<MyAccountsPage> {
  PageViewHolder holder;
  PageController _controller;
  double fraction = 1;
  List<Navegador> navegadores = [];
  Navegador navegador1;
  Navegador navegador2;
  Navegador navegador3;
  Navegador navegador4;
  bool boton = false;
  PanelController panelrutaController;
  WebViewController controller1;
  WebViewController controller2;
  WebViewController controller3;
  WebViewController controller4;
  List<WebViewController> controladores = [];
  bool bloqueo = false;
  String codeDialog;
  String valueText;
  TextEditingController _textFieldController = TextEditingController();

  List<Container> indicators = [];
  int currentPage = 0;

  // Interstitial Ads Code ----
  int interialAdPageCount = 1;
  InterstitialAd _interstitialAd;
  BannerAd _bottomBannerAd;
  NativeAd _ad;
  bool isNativeAdLoaded = false;
  bool _isBottomBannerAdLoaded = false;
  loadNativeAd() {
    _ad = NativeAd(
      adUnitId: 'ca-app-pub-5512694281985389/5725499850',
      factoryId: 'listTile',
      request: AdRequest(),
      listener: NativeAdListener(
        onAdLoaded: (ad) {
          setState(() {
            isNativeAdLoaded = true;
            _ad = ad as NativeAd;
          });
        },
        onAdFailedToLoad: (ad, error) {
          // Releases an ad resource when it fails to load
          ad.dispose();
          print('Ad load failed (code=${error.code} message=${error.message})');
        },
      ),
    );
    _ad.load();
  }

  void _createBottomBannerAd() {
    _bottomBannerAd = BannerAd(
      adUnitId: Galdy().bannerID,
      size: AdSize.banner,
      request: AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) {
          print('Banner ad loaded');
          setState(() {
            _isBottomBannerAdLoaded = true;
          });
        },
        onAdFailedToLoad: (ad, error) {
          print('Banner ad Failed ...' + error.message);
          ad.dispose();
        },
      ),
    );
    _bottomBannerAd.load();
  }

  loadInterstitialAd() {
    InterstitialAd.load(
      adUnitId: Galdy().interID,
      request: AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          // this._interstitialAd = ad;
          this._interstitialAd = ad;

          ad.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) {
              _interstitialAd.dispose();
              loadInterstitialAd();

              // forMoreFunction();
            },
          );

          // _isInterstitialAdReady = true;
        },
        onAdFailedToLoad: (err) {
          _interstitialAd.dispose();
          // Navigator.of(context).pop();
          // forMoreFunction();

          print('Failed to load an interstitial ad: ${err.message}');
          // _isInterstitialAdReady = false;
        },
      ),
    );
  }

  Widget updateIndicators() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: listaredes.map((course) {
        var index = listaredes.indexOf(course);
        return Container(
          width: 7.0,
          height: 7.0,
          margin: EdgeInsets.symmetric(horizontal: 6.0),
          decoration: BoxDecoration(
              shape: BoxShape.circle,
              color:
                  currentPage == index ? Color(0xFF0971FE) : Color(0xFFA6AEBD)),
        );
      }).toList(),
    );
  }

  @override
  void dispose() {
    super.dispose();
    _bottomBannerAd.dispose();
  }

  @override
  void initState() {
    super.initState();

    _createBottomBannerAd();
    loadInterstitialAd();
    loadNativeAd();

    String url1 = 'https://m.facebook.com';
    String url2 = 'https://m.instagram.com';
    String url3 = 'https://m.twitter.com';
    String url4 = 'https://www.pinterest.com';
    var nav = WebView(
      key: Key('n1'),
      initialUrl: url1,
      javascriptMode: JavascriptMode.unrestricted,
      onWebViewCreated: (WebViewController webViewController) {
        controller1 = webViewController;
      },
    );
    var nav2 = WebView(
      key: Key('n2'),
      initialUrl: url2,
      javascriptMode: JavascriptMode.unrestricted,
      onWebViewCreated: (WebViewController webViewController) {
        controller2 = webViewController;
      },
    );
    var nav3 = WebView(
      key: Key('n3'),
      initialUrl: url3,
      javascriptMode: JavascriptMode.unrestricted,
      onWebViewCreated: (WebViewController webViewController) {
        controller3 = webViewController;
      },
    );
    var nav4 = WebView(
      initialUrl: url4,
      key: Key('n4'),
      javascriptMode: JavascriptMode.unrestricted,
      onWebViewCreated: (WebViewController webViewController) {
        controller4 = webViewController;
      },
    );

    navegador1 = Navegador(nav);
    navegador2 = Navegador(nav2);
    navegador3 = Navegador(nav3);
    navegador4 = Navegador(nav4);

    navegadores.add(navegador1);
    navegadores.add(navegador2);
    navegadores.add(navegador3);
    navegadores.add(navegador4);

    controladores.add(controller1);
    controladores.add(controller2);
    controladores.add(controller3);
    controladores.add(controller4);

    holder = PageViewHolder(
      value: 2.0,
    );

    _controller = PageController(initialPage: 2, viewportFraction: fraction);
    _controller.addListener(() {
      holder.setValue(_controller.page);
    });
  }

  agregar(BuildContext context, WebViewController controller) {
    return FadeIn(
      3,
      Padding(
        padding: const EdgeInsets.only(right: 8),
        child: Align(
            alignment: Alignment.topRight,
            child: RawMaterialButton(
              onPressed: () {
                _alertaurl(context, controller);
              },
              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              highlightColor: Colors.transparent,
              splashColor: Colors.transparent,
              constraints: BoxConstraints(
                maxWidth: 50.0,
                maxHeight: 50.0,
              ),
              child: Container(
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14.0),
                    boxShadow: [
                      BoxShadow(
                        color: kShadowColor,
                        offset: Offset(0, 12),
                        blurRadius: 16.0,
                      )
                    ]),
                child: Center(
                  child: Icon(
                    Icons.add,
                    color: kSecondaryLabelColor,
                  ),
                ),
                padding: EdgeInsets.symmetric(
                  horizontal: 12.0,
                  vertical: 14.0,
                ),
              ),
            )),
      ),
    );
  }

  Future<void> _alertaurl(
      BuildContext context, WebViewController controller) async {
    return showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
                side: BorderSide.none,
                borderRadius: BorderRadius.all(Radius.circular(20))),
            elevation: 40,
            title: Text('Open URL'),
            content: TextField(
              onChanged: (value) {
                setState(() {
                  valueText = value;
                });
              },
              controller: _textFieldController,
              decoration: InputDecoration(hintText: "Url..."),
            ),
            actions: <Widget>[
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  primary: Colors.red,
                  onPrimary: Colors.white,
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text('CANCEL'),
              ),
              TextButton(
                style: TextButton.styleFrom(
                  backgroundColor: Colors.green,
                  primary: Colors.white,
                ),
                onPressed: () {
                  codeDialog = 'https://' + valueText;
                  controller.loadUrl(codeDialog);
                  Navigator.pop(context);
                  BlocProvider.of<CuboBloc>(context).add(Inicio());
                },
                child: Text('OK'),
              ),
            ],
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
      children: <Widget>[
        AnimatedBackground(),
        onBottom(AnimatedWave(
          height: 333,
          speed: 1.0,
        )),
        onBottom(AnimatedWave(
          height: 555,
          speed: 0.9,
          offset: math.pi,
        )),
        onBottom(AnimatedWave(
          height: 444,
          speed: 1.2,
          offset: math.pi / 2,
        )),
        SafeArea(
            child: Stack(
          children: [
            //aca esta el cubo

            AbsorbPointer(
              absorbing: bloqueo,
              child: Padding(
                padding: const EdgeInsets.only(bottom: 30),
                child: CubePageView.builder(
                    itemCount: navegadores.length,
                    onPageChanged: (value) async {
                      interialAdPageCount = interialAdPageCount + 1;
                      print(
                          'This is the On Page Changed Runs --- ${(interialAdPageCount % 5) == 0}');
                      if ((interialAdPageCount % 5) == 0) {
                        if (_interstitialAd != null) {
                          _interstitialAd.show();
                        }
                      }
                    },
                    itemBuilder: (context, index, notifier) {
                      final item = navegadores[index];
                      final transform = Matrix4.identity();
                      final t = (index - notifier).abs();
                      final scale = lerpDouble(1.5, 0, t);
                      transform.scale(scale, scale);
                      return CubeWidget(
                          index: index,
                          pageNotifier: notifier,
                          child: Stack(children: [
                            Transform(
                              alignment: Alignment.center,
                              transform: transform,
                            ),
                            item,
                          ]));
                    }),
              ),
            ),
            Positioned.fill(
              child: Align(
                  alignment: Alignment.bottomCenter,
                  child:
                      //aca el panel inferior
                      SlidingUpPanel(
                    backdropEnabled: true,
                    /*
      borderRadius: BorderRadius.only(
        topLeft: Radius.circular(34.0),
        topRight: Radius.circular(34.0),
      ),
      */
                    color: kCardPopupBackgroundColor,
                    boxShadow: [
                      BoxShadow(
                          color: kShadowColor,
                          offset: Offset(0, -12),
                          blurRadius: 32.0),
                    ],
                    minHeight: _isBottomBannerAdLoaded == true ? 50 : 30,
                    maxHeight: MediaQuery.of(context).size.height * 0.43,
                    panel: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        isNativeAdLoaded
                            ? Center(
                                child: Container(
                                  height:
                                      _bottomBannerAd.size.height.toDouble(),
                                  width: _bottomBannerAd.size.width.toDouble(),
                                  child: AdWidget(ad: _ad),
                                ),
                              )
                            : SizedBox(),
                        Center(
                          child: Padding(
                            padding: EdgeInsets.only(top: 12.0, bottom: 16.0),
                            child: Container(
                              width: 42.0,
                              height: 4.0,
                              decoration: BoxDecoration(
                                color: Color(0xFFC5CBD6),
                                borderRadius: BorderRadius.circular(2.0),
                              ),
                            ),
                          ),
                        ),

                        BlocBuilder<CuboBloc, Estado>(
                            builder: (contexto, state) {
                          if (state is InicioE) {
                            return FadeIn(1.4, ContinueWatchingList());
                          }

                          if (state is Lado1E) {
                            return Stack(children: [
                              FadeIn(
                                  1.8,
                                  Stack(children: [
                                    Positioned.fill(
                                      child: Align(
                                        alignment: Alignment.bottomCenter,
                                        child: updateIndicators(),
                                      ),
                                    ),
                                    Container(
                                      height: 200.0,
                                      width: double.infinity,
                                      child: PageView.builder(
                                        itemBuilder: (context, index) {
                                          var ima = 'facebook.png';
                                          var pagina = 'https://m.facebook.com';
                                          if (index == 0) {
                                            ima = 'facebook.png';
                                          }
                                          if (index == 1) {
                                            ima = 'instagram.png';
                                          }
                                          if (index == 2) {
                                            ima = 'tiktok.png';
                                          }
                                          if (index == 3) {
                                            ima = 'twitter.png';
                                          }
                                          if (index == 4) {
                                            ima = 'youtube.png';
                                          }
                                          if (index == 5) {
                                            ima = 'pinterest.png';
                                          }
                                          return Opacity(
                                              opacity: 1,
                                              child: GestureDetector(
                                                child: Padding(
                                                  padding: const EdgeInsets.all(
                                                      20.0),
                                                  child: Image.asset(
                                                    'assets/$ima',
                                                    fit: BoxFit.fitHeight,
                                                    height: 160,
                                                  ),
                                                ),
                                                onTap: () {
                                                  if (index == 0) {
                                                    pagina =
                                                        'https://m.facebook.com';
                                                  }
                                                  if (index == 1) {
                                                    pagina =
                                                        'https://m.instagram.com';
                                                  }
                                                  if (index == 2) {
                                                    pagina =
                                                        'https://m.tiktok.com';
                                                  }
                                                  if (index == 3) {
                                                    pagina =
                                                        'https://m.twitter.com';
                                                  }
                                                  if (index == 4) {
                                                    pagina =
                                                        'https://m.youtube.com';
                                                  }
                                                  if (index == 5) {
                                                    pagina =
                                                        'https://www.pinterest.com';
                                                  }
                                                  setState(() {
                                                    controller1.loadUrl(pagina);
                                                    BlocProvider.of<CuboBloc>(
                                                            context)
                                                        .add(Inicio());
                                                  });
                                                  if (_interstitialAd != null) {
                                                    _interstitialAd.show();
                                                  }
                                                  print(index);
                                                },
                                              ));
                                        },
                                        itemCount: listaredes.length,
                                        onPageChanged: (index) {
                                          setState(() {
                                            currentPage = index;
                                          });
                                        },
                                        controller: PageController(
                                            initialPage: 0,
                                            viewportFraction: 0.75),
                                      ),
                                    ),
                                  ])),
                              agregar(context, controller1),
                              volver(),
                            ]);
                          }

                          if (state is Lado2E) {
                            return Stack(children: [
                              FadeIn(
                                  1.8,
                                  Stack(children: [
                                    Positioned.fill(
                                      child: Align(
                                        alignment: Alignment.bottomCenter,
                                        child: updateIndicators(),
                                      ),
                                    ),
                                    Container(
                                      height: 200.0,
                                      width: double.infinity,
                                      child: PageView.builder(
                                        itemBuilder: (context, index) {
                                          var ima = 'facebook.png';
                                          var pagina = 'https://m.facebook.com';
                                          if (index == 0) {
                                            ima = 'facebook.png';
                                          }
                                          if (index == 1) {
                                            ima = 'instagram.png';
                                          }
                                          if (index == 2) {
                                            ima = 'tiktok.png';
                                          }
                                          if (index == 3) {
                                            ima = 'twitter.png';
                                          }
                                          if (index == 4) {
                                            ima = 'youtube.png';
                                          }
                                          if (index == 5) {
                                            ima = 'pinterest.png';
                                          }
                                          return Opacity(
                                              opacity: 1,
                                              child: GestureDetector(
                                                child: Padding(
                                                  padding: const EdgeInsets.all(
                                                      20.0),
                                                  child: Image.asset(
                                                    'assets/$ima',
                                                    fit: BoxFit.fitHeight,
                                                    height: 160,
                                                  ),
                                                ),
                                                onTap: () {
                                                  if (index == 0) {
                                                    pagina =
                                                        'https://m.facebook.com';
                                                  }
                                                  if (index == 1) {
                                                    pagina =
                                                        'https://m.instagram.com';
                                                  }
                                                  if (index == 2) {
                                                    pagina =
                                                        'https://m.tiktok.com';
                                                  }
                                                  if (index == 3) {
                                                    pagina =
                                                        'https://m.twitter.com';
                                                  }
                                                  if (index == 4) {
                                                    pagina =
                                                        'https://m.youtube.com';
                                                  }
                                                  if (index == 5) {
                                                    pagina =
                                                        'https://www.pinterest.com';
                                                  }
                                                  setState(() {
                                                    controller2.loadUrl(pagina);
                                                    BlocProvider.of<CuboBloc>(
                                                            context)
                                                        .add(Inicio());
                                                  });
                                                  if (_interstitialAd != null) {
                                                    _interstitialAd.show();
                                                  }
                                                  print(index);
                                                },
                                              ));
                                        },
                                        itemCount: listaredes.length,
                                        onPageChanged: (index) {
                                          setState(() {
                                            currentPage = index;
                                          });
                                        },
                                        controller: PageController(
                                            initialPage: 0,
                                            viewportFraction: 0.75),
                                      ),
                                    ),
                                  ])),
                              agregar(context, controller2),
                              volver(),
                            ]);
                          }

                          if (state is Lado3E) {
                            return Stack(children: [
                              FadeIn(
                                  1.8,
                                  Stack(children: [
                                    Positioned.fill(
                                      child: Align(
                                        alignment: Alignment.bottomCenter,
                                        child: updateIndicators(),
                                      ),
                                    ),
                                    Container(
                                      height: 200.0,
                                      width: double.infinity,
                                      child: PageView.builder(
                                        itemBuilder: (context, index) {
                                          var ima = 'facebook.png';
                                          var pagina = 'https://m.facebook.com';
                                          if (index == 0) {
                                            ima = 'facebook.png';
                                          }
                                          if (index == 1) {
                                            ima = 'instagram.png';
                                          }
                                          if (index == 2) {
                                            ima = 'tiktok.png';
                                          }
                                          if (index == 3) {
                                            ima = 'twitter.png';
                                          }
                                          if (index == 4) {
                                            ima = 'youtube.png';
                                          }
                                          if (index == 5) {
                                            ima = 'pinterest.png';
                                          }
                                          return Opacity(
                                              opacity: 1,
                                              child: GestureDetector(
                                                child: Padding(
                                                  padding: const EdgeInsets.all(
                                                      20.0),
                                                  child: Image.asset(
                                                    'assets/$ima',
                                                    fit: BoxFit.fitHeight,
                                                    height: 160,
                                                  ),
                                                ),
                                                onTap: () {
                                                  if (index == 0) {
                                                    pagina =
                                                        'https://m.facebook.com';
                                                  }
                                                  if (index == 1) {
                                                    pagina =
                                                        'https://m.instagram.com';
                                                  }
                                                  if (index == 2) {
                                                    pagina =
                                                        'https://m.tiktok.com';
                                                  }
                                                  if (index == 3) {
                                                    pagina =
                                                        'https://m.twitter.com';
                                                  }
                                                  if (index == 4) {
                                                    pagina =
                                                        'https://m.youtube.com';
                                                  }
                                                  if (index == 5) {
                                                    pagina =
                                                        'https://www.pinterest.com';
                                                  }
                                                  setState(() {
                                                    controller3.loadUrl(pagina);
                                                    BlocProvider.of<CuboBloc>(
                                                            context)
                                                        .add(Inicio());
                                                  });
                                                  if (_interstitialAd != null) {
                                                    _interstitialAd.show();
                                                  }
                                                  print(index);
                                                },
                                              ));
                                        },
                                        itemCount: listaredes.length,
                                        onPageChanged: (index) {
                                          setState(() {
                                            currentPage = index;
                                          });
                                        },
                                        controller: PageController(
                                            initialPage: 0,
                                            viewportFraction: 0.75),
                                      ),
                                    ),
                                  ])),
                              agregar(context, controller3),
                              volver(),
                            ]);
                          }

                          if (state is Lado4E) {
                            return Stack(children: [
                              FadeIn(
                                  1.8,
                                  Stack(children: [
                                    Positioned.fill(
                                      child: Align(
                                        alignment: Alignment.bottomCenter,
                                        child: updateIndicators(),
                                      ),
                                    ),
                                    Container(
                                      height: 200.0,
                                      width: double.infinity,
                                      child: PageView.builder(
                                        itemBuilder: (context, index) {
                                          var ima = 'facebook.png';
                                          var pagina = 'https://m.facebook.com';
                                          if (index == 0) {
                                            ima = 'facebook.png';
                                          }
                                          if (index == 1) {
                                            ima = 'instagram.png';
                                          }
                                          if (index == 2) {
                                            ima = 'tiktok.png';
                                          }
                                          if (index == 3) {
                                            ima = 'twitter.png';
                                          }
                                          if (index == 4) {
                                            ima = 'youtube.png';
                                          }
                                          if (index == 5) {
                                            ima = 'pinterest.png';
                                          }
                                          return Opacity(
                                              opacity: 1,
                                              child: GestureDetector(
                                                child: Padding(
                                                  padding: const EdgeInsets.all(
                                                      20.0),
                                                  child: Image.asset(
                                                    'assets/$ima',
                                                    fit: BoxFit.fitHeight,
                                                    height: 160,
                                                  ),
                                                ),
                                                onTap: () {
                                                  if (index == 0) {
                                                    pagina =
                                                        'https://m.facebook.com';
                                                  }
                                                  if (index == 1) {
                                                    pagina =
                                                        'https://m.instagram.com';
                                                  }
                                                  if (index == 2) {
                                                    pagina =
                                                        'https://m.tiktok.com';
                                                  }
                                                  if (index == 3) {
                                                    pagina =
                                                        'https://m.twitter.com';
                                                  }
                                                  if (index == 4) {
                                                    pagina =
                                                        'https://m.youtube.com';
                                                  }
                                                  if (index == 5) {
                                                    pagina =
                                                        'https://www.pinterest.com';
                                                  }
                                                  setState(() {
                                                    controller4.loadUrl(pagina);
                                                    BlocProvider.of<CuboBloc>(
                                                            context)
                                                        .add(Inicio());
                                                  });
                                                  if (_interstitialAd != null) {
                                                    _interstitialAd.show();
                                                  }
                                                  print(index);
                                                },
                                              ));
                                        },
                                        itemCount: listaredes.length,
                                        onPageChanged: (index) {
                                          setState(() {
                                            currentPage = index;
                                          });
                                        },
                                        controller: PageController(
                                            initialPage: 0,
                                            viewportFraction: 0.75),
                                      ),
                                    ),
                                  ])),
                              agregar(context, controller4),
                              volver(),
                            ]);
                          }

                          return SizedBox(
                            height: 0,
                          );
                        }),

                        // bloquear(),
                      ],
                    ),
                  )),
            )
          ],
        )),
      ],
    ));
  }

  onBottom(Widget child) => Positioned.fill(
        child: Align(
          alignment: Alignment.bottomCenter,
          child: child,
        ),
      );

  volver() {
    return FadeIn(
      2,
      Padding(
        padding: const EdgeInsets.only(left: 8),
        child: Align(
            alignment: Alignment.topLeft,
            child: RawMaterialButton(
              onPressed: () {
                BlocProvider.of<CuboBloc>(context).add(Inicio());
              },
              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              highlightColor: Colors.transparent,
              splashColor: Colors.transparent,
              constraints: BoxConstraints(
                maxWidth: 50.0,
                maxHeight: 50.0,
              ),
              child: Container(
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14.0),
                    boxShadow: [
                      BoxShadow(
                        color: kShadowColor,
                        offset: Offset(0, 12),
                        blurRadius: 16.0,
                      )
                    ]),
                child: Center(
                  child: Icon(
                    Icons.arrow_back,
                    color: kSecondaryLabelColor,
                  ),
                ),
                padding: EdgeInsets.symmetric(
                  horizontal: 12.0,
                  vertical: 14.0,
                ),
              ),
            )),
      ),
    );
  }

/*
bloquear(){

   return FadeIn(2, Padding(
     padding: const EdgeInsets.only(right: 8,bottom: 8),
     child: Align(
          alignment: Alignment.bottomRight,child:RawMaterialButton(
          onPressed:  (){
            print('piro'+bloqueo.toString());

                                      bloqueo = !bloqueo;


          },
          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          highlightColor: Colors.transparent,
          splashColor: Colors.transparent,
          constraints: BoxConstraints(
            maxWidth: 50.0,
            maxHeight: 50.0,
          ),
          child: Container(
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14.0),
                boxShadow: [
                  BoxShadow(
                    color: kShadowColor,
                    offset: Offset(0, 12),
                    blurRadius: 16.0,
                  )
                ]),
            child: Center(
              child: Icon(
                                      Icons.lock,
                                      color: kSecondaryLabelColor,
                                    ),
            ),
            padding: EdgeInsets.symmetric(
              horizontal: 12.0,
              vertical: 14.0,
            ),
          ),
        )),
   ),
   );

}

*/
}

Widget botonDan(String titulo, Color color, Icon icon) {
  return Container(
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: color,
        boxShadow: [
          BoxShadow(
            color: kShadowColor,
            offset: Offset(0, 16),
            blurRadius: 22.0,
          )
        ],
        borderRadius: BorderRadius.circular(30.0),
      ),
      height: 60.0,
      child: Stack(
        children: [
          Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.only(left: 16.0),
                child: icon,
              )),
          Align(
            alignment: Alignment.center,
            child: Text(
              titulo,
              style: kSearchTextStyle2,
            ),
          )
        ],
      ));
}

class AnimatedBackground extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final tween = MultiTrackTween([
      Track("color1").add(
          Duration(seconds: 3),
          ColorTween(
              begin: Color(int.parse('0xff' + Galdy().color1)),
              end: Color(int.parse('0xff' + Galdy().color2)))),
      Track("color2").add(
          Duration(seconds: 3),
          ColorTween(
              begin: Color(int.parse('0xff' + Galdy().color1)),
              end: Color(int.parse('0xff' + Galdy().color2))))
    ]);

    return ControlledAnimation(
      playback: Playback.MIRROR,
      tween: tween,
      duration: tween.duration,
      builder: (context, animation) {
        return Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [animation["color1"], animation["color2"]])),
        );
      },
    );
  }
}

class AnimatedWave extends StatelessWidget {
  final double height;
  final double speed;
  final double offset;

  AnimatedWave({this.height, this.speed, this.offset = 0.0});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      return Container(
        height: height,
        width: constraints.biggest.width,
        child: ControlledAnimation(
            playback: Playback.LOOP,
            duration: Duration(milliseconds: (8000 / speed).round()),
            tween: Tween(begin: 0.0, end: 2 * math.pi),
            builder: (context, value) {
              return CustomPaint(
                foregroundPainter: CurvePainter(value + offset),
              );
            }),
      );
    });
  }
}

class CurvePainter extends CustomPainter {
  final double value;

  CurvePainter(this.value);

  @override
  void paint(Canvas canvas, Size size) {
    final white = Paint()..color = Colors.white.withAlpha(60);
    final path = Path();

    final y1 = math.sin(value);
    final y2 = math.sin(value + math.pi / 2);
    final y3 = math.sin(value + math.pi);

    final startPointY = size.height * (0.5 + 0.4 * y1);
    final controlPointY = size.height * (0.5 + 0.4 * y2);
    final endPointY = size.height * (0.5 + 0.4 * y3);

    path.moveTo(size.width * 0, startPointY);
    path.quadraticBezierTo(
        size.width * 0.5, controlPointY, size.width, endPointY);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close();
    canvas.drawPath(path, white);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}

class MyPage extends StatefulWidget {
  final double number;
  final double fraction;

  MyPage({this.number, this.fraction});

  @override
  _MyPageState createState() => _MyPageState();
}

class _MyPageState extends State<MyPage> {
  @override
  Widget build(BuildContext context) {
    double value = Provider.of<PageViewHolder>(context).value;
    double diff = (widget.number - value);
    // print('aca'+diff.toString());

    @override
    //Matrix for Elements
        final Matrix4 pvMatrix = Matrix4.identity()
          ..setEntry(3, 3, 1 / 0.9) // Increasing Scale by 90%
          ..setEntry(1, 1, 0.5) // Changing Scale Along Y Axis
          ..setEntry(3, 0, 0.004 * -diff);

    return Stack(
      fit: StackFit.expand,
      alignment: Alignment.center,
      children: <Widget>[
        Transform(
          transform: pvMatrix,
          alignment: FractionalOffset.center,
          child: Container(
            child: Image.asset(
              "assets/fondo.jpg",
              fit: BoxFit.fill,
            ),
          ),
        )
      ],
    );
  }
}

class PageViewHolder extends ChangeNotifier {
  double value;

  PageViewHolder({this.value});

  void setValue(newValue) {
    this.value = newValue;

    // print('esto es:'+value.toString());
    notifyListeners();
  }
}

class AnimatedBackground2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final tween = MultiTrackTween([
      Track("color1").add(Duration(seconds: 3),
          ColorTween(begin: Color(0xff7F7FD5), end: Color(0xff91EAE4))),
      Track("color2").add(Duration(seconds: 3),
          ColorTween(begin: Color(0xff7F7FD5), end: Color(0xff86A8E7)))
    ]);

    return ControlledAnimation(
      playback: Playback.MIRROR,
      tween: tween,
      duration: tween.duration,
      builder: (context, animation) {
        return Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [animation["color1"], animation["color2"]])),
        );
      },
    );
  }
}

class FadeAnimation extends StatelessWidget {
  final double delay;
  final Widget child;

  FadeAnimation(this.delay, this.child);

  @override
  Widget build(BuildContext context) {
    final tween = MultiTrackTween([
      Track("opacity")
          .add(Duration(milliseconds: 500), Tween(begin: 0.0, end: 1.0)),
      Track("translateY").add(
          Duration(milliseconds: 500), Tween(begin: 130.0, end: 0.0),
          curve: Curves.easeOut)
    ]);

    return ControlledAnimation(
      delay: Duration(milliseconds: (500 * delay).round()),
      duration: tween.duration,
      tween: tween,
      child: child,
      builderWithChild: (context, child, animation) => Opacity(
        opacity: animation["opacity"],
        child: Transform.translate(
            offset: Offset(0, animation["translateY"]), child: child),
      ),
    );
  }
}

enum _AniProps { opacity, translateX }

class FadeIn extends StatelessWidget {
  final double delay;
  final Widget child;

  FadeIn(this.delay, this.child);

  @override
  Widget build(BuildContext context) {
    final tween = MultiTween<_AniProps>()
      ..add(_AniProps.opacity, 0.0.tweenTo(1.0))
      ..add(_AniProps.translateX, 130.0.tweenTo(0.0));

    return PlayAnimation<MultiTweenValues<_AniProps>>(
      delay: (300 * delay).round().milliseconds,
      duration: 500.milliseconds,
      tween: tween,
      child: child,
      builder: (context, child, value) => Opacity(
        opacity: value.get(_AniProps.opacity),
        child: Transform.translate(
          offset: Offset(value.get(_AniProps.translateX), 0),
          child: child,
        ),
      ),
    );
  }
}

/// Signature for a function that creates a widget for a given index in a [CubePageView]
///
/// Used by [CubePageView.builder] and other APIs that use lazily-generated widgets.
///
typedef CubeWidgetBuilder = CubeWidget Function(
    BuildContext context, int index, double pageNotifier);

/// This Widget has the [PageView] widget inside.
/// It works in two modes :
///   1 - Using the default constructor [CubePageView] passing the items in `children` property.
///   2 - Using the factory constructor [CubePageView.builder] passing a `itemBuilder` and `itemCount` properties.

class CubePageView extends StatefulWidget {
  /// Called whenever the page in the center of the viewport changes.
  final ValueChanged<int> onPageChanged;

  /// An object that can be used to control the position to which this page
  /// view is scrolled.
  final PageController controller;

  /// Builder to customize your items
  final CubeWidgetBuilder itemBuilder;

  /// The number of items you have, this is only required if you use [CubePageView.builder]
  final int itemCount;

  /// Widgets you want to use inside the [CubePageView], this is only required if you use [CubePageView] constructor
  final List<Widget> children;

  /// Creates a scrollable list that works page by page from an explicit [List]
  /// of widgets.
  const CubePageView({
    Key key,
    this.onPageChanged,
    this.controller,
    @required this.children,
  })  : itemBuilder = null,
        itemCount = null,
        assert(children != null),
        super(key: key);

  /// Creates a scrollable list that works page by page using widgets that are
  /// created on demand.
  ///
  /// This constructor is appropriate if you want to customize the behavior
  ///
  /// Providing a non-null [itemCount] lets the [CubePageView] compute the maximum
  /// scroll extent.
  ///
  /// [itemBuilder] will be called only with indices greater than or equal to
  /// zero and less than [itemCount].

  CubePageView.builder({
    Key key,
    @required this.itemCount,
    @required this.itemBuilder,
    this.onPageChanged,
    this.controller,
  })  : this.children = null,
        assert(itemCount != null),
        assert(itemBuilder != null),
        super(key: key);

  @override
  _CubePageViewState createState() => _CubePageViewState();
}

class _CubePageViewState extends State<CubePageView> {
  final _pageNotifier = ValueNotifier(0.0);
  PageController _pageController;

  void _listener() {
    _pageNotifier.value = _pageController.page;
  }

  @override
  void initState() {
    _pageController = widget.controller ?? PageController();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _pageController.addListener(_listener);
    });
    super.initState();
  }

  @override
  void dispose() {
    _pageController.removeListener(_listener);
    _pageController.dispose();
    _pageNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: Center(
        child: ValueListenableBuilder<double>(
          valueListenable: _pageNotifier,
          builder: (_, value, child) => PageView.builder(
            controller: _pageController,
            onPageChanged: widget.onPageChanged,
            physics: const BouncingScrollPhysics(),
            itemCount: widget.itemCount ?? widget.children.length,
            itemBuilder: (_, index) {
              if (widget.itemBuilder != null)
                return widget.itemBuilder(context, index, value);
              return CubeWidget(
                child: widget.children[index],
                index: index,
                pageNotifier: value,
              );
            },
          ),
        ),
      ),
    );
  }
}

/// This widget has the logic to do the 3D cube transformation
/// It only should be used if you use [CubePageView.builder]

class CubeWidget extends StatelessWidget {
  /// Index of the current item
  final int index;

  /// Page Notifier value, it comes from the [CubeWidgetBuilder]
  final double pageNotifier;

  /// Child you want to use inside the Cube
  final Widget child;

  const CubeWidget({
    Key key,
    @required this.index,
    @required this.pageNotifier,
    @required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isLeaving = (index - pageNotifier) <= 0;
    final t = (index - pageNotifier);
    final rotationY = lerpDouble(0, 90, t);
    final opacity = lerpDouble(0, 1, t.abs()).clamp(0.0, 1.0);
    final transform = Matrix4.identity();
    transform.setEntry(3, 2, 0.003);
    transform.rotateY(-degToRad(rotationY));
    return Transform(
      alignment: isLeaving ? Alignment.centerRight : Alignment.centerLeft,
      transform: transform,
      child: Stack(
        children: [child],
      ),
    );
  }
}

num degToRad(num deg) => deg * (math.pi / 180.0);

num radToDeg(num rad) => rad * (180.0 / math.pi);

class ContinueWatchingList extends StatefulWidget {
  @override
  _ContinueWatchingListState createState() => _ContinueWatchingListState();
}

class _ContinueWatchingListState extends State<ContinueWatchingList> {
  List<Container> indicators = [];
  int currentPage = 0;

  Widget updateIndicators() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: continueWatchingCourses.map((course) {
        var index = continueWatchingCourses.indexOf(course);
        return Container(
          width: 7.0,
          height: 7.0,
          margin: EdgeInsets.symmetric(horizontal: 6.0),
          decoration: BoxDecoration(
              shape: BoxShape.circle,
              color:
                  currentPage == index ? Color(0xFF0971FE) : Color(0xFFA6AEBD)),
        );
      }).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          height: 200.0,
          width: double.infinity,
          child: PageView.builder(
            itemBuilder: (context, index) {
              return Opacity(
                  opacity: currentPage == index ? 1.0 : 0.5,
                  child: GestureDetector(
                    child: ContinueWatchingCard(
                      course: continueWatchingCourses[index],
                    ),
                    onTap: () {
                      print(index);
                    },
                  ));
            },
            itemCount: continueWatchingCourses.length,
            onPageChanged: (index) {
              setState(() {
                currentPage = index;
              });
            },
            controller: PageController(initialPage: 0, viewportFraction: 0.75),
          ),
        ),
        updateIndicators(),
      ],
    );
  }
}

class ContinueWatchingCard extends StatelessWidget {
  ContinueWatchingCard({this.course});

  final Course course;

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.topCenter,
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          Padding(
            padding: EdgeInsets.only(
              top: 20.0,
              right: 20.0,
            ),
            child: GestureDetector(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: course.background,
                    borderRadius: BorderRadius.circular(41.0),
                    boxShadow: [
                      BoxShadow(
                        color: course.background.colors[0].withOpacity(0.3),
                        offset: Offset(0, 20),
                        blurRadius: 20.0,
                      ),
                      BoxShadow(
                        color: course.background.colors[1].withOpacity(0.3),
                        offset: Offset(0, 20),
                        blurRadius: 20.0,
                      )
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(41.0),
                    child: Container(
                      height: 140.0,
                      width: 260.0,
                      child: Stack(
                        children: [
                          Row(
                            children: [
                              Spacer(),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Image.asset(
                                    'assets/${course.illustration}',
                                    fit: BoxFit.cover,
                                    height: 110,
                                  ),
                                ],
                              ),
                            ],
                          ),
                          Padding(
                            padding: EdgeInsets.all(32.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  course.courseSubtitle,
                                  style: kCardSubtitleStyle,
                                ),
                                SizedBox(
                                  height: 6.0,
                                ),
                                Text(
                                  course.courseTitle,
                                  style: kCardTitleStyle,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                onTap: () {
                  if (course.courseTitle == "SIDE 1") {
                    BlocProvider.of<CuboBloc>(context).add(Lado1());
                  }
                  if (course.courseTitle == "SIDE 2") {
                    BlocProvider.of<CuboBloc>(context).add(Lado2());
                  }
                  if (course.courseTitle == "SIDE 3") {
                    BlocProvider.of<CuboBloc>(context).add(Lado3());
                  }
                  if (course.courseTitle == "SIDE 4") {
                    BlocProvider.of<CuboBloc>(context).add(Lado4());
                  }
                }),
          )
        ],
      ),
    );
  }
}

class Course {
  Course({
    this.courseTitle,
    this.courseSubtitle,
    this.background,
    this.illustration,
    this.logo,
  });

  String courseTitle;
  String courseSubtitle;
  LinearGradient background;
  String illustration;
  String logo;
}

// Continue Watching Courses
var continueWatchingCourses = [
  Course(
    courseTitle: "SIDE 1",
    courseSubtitle: "Select Cube Face 1",
    background: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        Color(0xFF4E62CC),
        Color(0xFF202A78),
      ],
    ),
    illustration: 'illustration-06.png',
  ),
  Course(
    courseTitle: "SIDE 2",
    courseSubtitle: "Select Cube Face 2",
    background: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        Color(0xFFFA7D75),
        Color(0xFFC23D61),
      ],
    ),
    illustration: 'illustration-07.png',
  ),
  Course(
    courseTitle: "SIDE 3",
    courseSubtitle: "Select Cube Face 3",
    background: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        Color(0xFFFA7D75),
        Color(0xFFC23D61),
      ],
    ),
    illustration: 'illustration-08.png',
  ),
  Course(
    courseTitle: "SIDE 4",
    courseSubtitle: "Select Cube Face 4",
    background: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        Color(0xFFFA7D75),
        Color(0xFFC23D61),
      ],
    ),
    illustration: 'illustration-09.png',
  ),
];

// Continue Watching Courses
var listaredes = [
  Course(
    courseTitle: "facebook",
    courseSubtitle: "",
    illustration: 'facebook.png',
  ),
  Course(
    courseTitle: "instagram",
    courseSubtitle: "",
    illustration: 'instagram.png',
  ),
  Course(
    courseTitle: "tiktok",
    courseSubtitle: "",
    illustration: 'tiktok.png',
  ),
  Course(
    courseTitle: "youtube",
    courseSubtitle: "",
    illustration: 'youtube.png',
  ),
  Course(
    courseTitle: "twitter",
    courseSubtitle: "",
    illustration: 'twitter.png',
  ),
  Course(
    courseTitle: "pinterest",
    courseSubtitle: "",
    illustration: 'pinterest.png',
  ),
];

/*
           var pagina = '';
        if(course.courseTitle == 'facebook'){
            pagina ='https://m.facebook.com';
        }
        if(course.courseTitle == 'instagram'){
            pagina ='https://m.instagram.com';
        }
        if(course.courseTitle == 'twitter'){
            pagina ='https://m.twitter.com';
        }
        if(course.courseTitle == 'pinterest'){
            pagina ='https://www.pinterest.com';
        }
        if(course.courseTitle == 'tiktok'){
            pagina ='https://m.tiktok.com';
        }
        if(course.courseTitle == 'youtube'){
            pagina ='https://m.youtube.com';
        }



        */
