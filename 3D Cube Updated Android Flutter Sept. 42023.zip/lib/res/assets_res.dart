/// Generated file. Do not edit.

// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars
class AssetsRes {
}
