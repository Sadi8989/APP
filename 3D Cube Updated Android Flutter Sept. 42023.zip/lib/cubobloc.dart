

import 'package:SocialNetworksAllinOne/estado.dart';
import 'package:SocialNetworksAllinOne/eventos.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CuboBloc extends Bloc<Evento, Estado> {
  CuboBloc(Estado initialState);


  

  @override
  Stream<Estado> mapEventToState(Evento event) async* {
     if (event is Inicio) {
         yield* _inicio();
          }

          if (event is Lado1) {
         yield* _lado1();
          }
          if (event is Lado2) {
         yield* _lado2();
          }
          if (event is Lado3) {
         yield* _lado3();
          }
          if (event is Lado4) {
         yield* _lado4();
          }

          

          
        }


       Stream<Estado> _inicio() async* {
          try {
              print('inicio');
            yield InicioE();
          } catch (_) {
            yield ErrorE();
          }
      }

      Stream<Estado> _lado1() async* {
          try {
            print('lado1');
            yield Lado1E();
          } catch (_) {
            yield ErrorE();
          }
      }

      Stream<Estado> _lado2() async* {
          try {
            print('lado2');
            yield Lado2E();
          } catch (_) {
            yield ErrorE();
          }
      }

      Stream<Estado> _lado3() async* {
          try {
            print('lado 3');
            yield Lado3E();
          } catch (_) {
            yield ErrorE();
          }
      }
      Stream<Estado> _lado4() async* {
          try {
            print('lado4');
            yield Lado4E();
          } catch (_) {
            yield ErrorE();
          }
      }

  @override
  Estado get initialState => InicioE();


       

     
}