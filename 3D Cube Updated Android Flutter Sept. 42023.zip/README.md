## MoviePedia

This project is a test application using Flutter and [TheMovieDB](https://www.themoviedb.org/).
TheMovieDB is used for the movies api like popular movies, upcoming movies, now playing movies and their details.

I have used Bloc pattern in this application

![](screenshots/showcase.gif)